This is an advanced version of the original report. Is does not categorise the items in Not in Stock, Not Able to Produce, Able to Produce and No Action Required.
Instead, a "traffic light system" is used. The meaning of red, yellow and green are as followed:

		Einkauf			Fertigungsartikel

Red: 	The item is not available	Can't be produced
Yellow:	-				Can be produced. However, if this item will be produced, other items marked as yellow cannot be produced anymore
Green:	The item is available		The item can be produced and does not interfer with any other item.